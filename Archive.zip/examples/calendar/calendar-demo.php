

<!--   *** DETAIL ***-->
<div class="col-md-8 col-lg-9 content-column white-background">
    <div class="small-navbar d-flex d-md-none">
      <button type="button" data-toggle="offcanvas" class="btn btn-outline-primary"> <i class="fa fa-align-left mr-2"></i>Menu</button>
      <h1 class="small-navbar-heading"> <a href="index.html">Creative </a></h1>
    </div>

    <div class="row">
      <div class="col-xl-10">
        <div class="content-column-content">
          <h1>Calendar Demo</h1>
          <?php include("calendar.php");?>
        </div>
      </div>
    </div>

  </div>

  