<?php

	//array Navigation 
	$serviceItems = array (
	
						array(
							glyphicon 	=> "glyphicon-picture",
							title		=> "COLOURS",
							blurb		=> "to fill your heart"
						),
						array(
							glyphicon 	=> "glyphicon-tint",
							title		=> "ENGAGEMENT",
							blurb		=> "attention and thought"
						),
						array(
							glyphicon 	=> "glyphicon-heart",
							title		=> "BEAUTY",
							blurb		=> "to touch your heart"
						),
						array(
							glyphicon 	=> "glyphicon-thumbs-up",
							title		=> "JOB DONE",
							blurb		=> "meeting expectations"
						),
						array(
							glyphicon 	=> "glyphicon-euro",
							title		=> "VALUE",
							blurb		=> "for your money"
						),
						array(
							glyphicon 	=> "glyphicon-retweet",
							title		=> "IMPACT",
							blurb		=> "reach-out to others"
						)
				);
	
	$portfolios = array (
	
						array (
							img 	=>	"Loopzand",
							title	=>	"Abstract",
							blurb	=>	"Manifesting"
						),
						array (
							img 	=>	"meadows",
							title	=>	"Perspective",
							blurb	=>	"Reality"
						),
						array (
							img 	=>	"phdstudy",
							title	=>	"Lines",
							blurb	=>	"Straight"
						)
	
				  );
				  
	/* this coding is a part of the carousel. It did not work !!
	$feedbacks = array (
	
					array(
						comment	=>	"Balanced colour comparison. Very happy !",
						name	=>	"Michael Roe",
						position=>	"President",
						company	=>	"ABC & Co."
					),
					array(
						comment	=>	"Panoramic landscaping is good.",
						name	=>	"John Doe",
						position=>	"Creative Director",
						company	=>	"ZOOM"
					),
					array(
						comment	=>	"Balanced colour comparison. Very happy !",
						name	=>	"Jane Jane",
						position=>	"Project Director",
						company	=>	"Brightside Investing"
					)
				
				);
		*/
		
		$prices = array (
	
						array (
							level 		=>	"Basic",
							pics		=>	200,
							song		=>	5000,
							movie		=> 	100,
							cost		=>	20,
							butTarget	=>	"media/Loopzand.jpg"
						),
						array (
							level 		=>	"Medium",
							pics		=>	200,
							song		=>	10000,
							movie		=> 	500,
							cost		=>	60,
							butTarget	=>	"media/meadows.jpg"
						),
						array (
							level 		=>	"Advanced",
							pics		=>	"Unlimited",
							song		=>	"Unlimited",
							movie		=> 	"Unlimited",
							cost		=>	120,
							butTarget	=>	"media/phdstudy.jpg"
						)
	
				  );
?>